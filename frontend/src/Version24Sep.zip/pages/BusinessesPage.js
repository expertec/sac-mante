import React, { useState, useEffect, useCallback } from "react";
import {
  getFirestore,
  collection,
  addDoc,
  getDocs,
  updateDoc,
  onSnapshot,
  doc,
} from "firebase/firestore";
import { getStorage, ref, uploadString, getDownloadURL } from "firebase/storage";
import BusinessForm from "../components/BusinessForm"; // Formulario multi-step para registro
import { FaTimes } from "react-icons/fa";
import { getAuth } from "firebase/auth";
import * as XLSX from "xlsx"; // Para exportar a Excel
import dayjs from "dayjs";

// Componente BusinessEditForm (actualizado para usar openingTime/closingTime)
function BusinessEditForm({
  newBusiness,
  handleInputChange,
  handleFormSubmit,
  handleCancel,
  agentMapping,
  handleScheduleChange,
}) {
  const daysOfWeek = [
    "Lunes",
    "Martes",
    "Miércoles",
    "Jueves",
    "Viernes",
    "Sábado",
    "Domingo",
  ];

  return (
    <form onSubmit={handleFormSubmit} className="space-y-2">
      {/* Primera fila: Nombre y Dueño */}
      <div className="flex flex-col sm:flex-row sm:space-x-2">
        <input
          type="text"
          name="name"
          value={newBusiness.name}
          onChange={handleInputChange}
          placeholder="Nombre del negocio"
          className="w-full sm:w-1/2 px-3 py-2 border rounded"
          required
        />
        <input
          type="text"
          name="owner"
          value={newBusiness.owner}
          onChange={handleInputChange}
          placeholder="Dueño"
          className="w-full sm:w-1/2 px-3 py-2 border rounded"
          required
        />
      </div>
      {/* Segunda fila: WhatsApp y Giro comercial */}
      <div className="flex flex-col sm:flex-row sm:space-x-2">
        <input
          type="text"
          name="phone"
          value={newBusiness.phone}
          onChange={handleInputChange}
          placeholder="WhatsApp"
          className="w-full sm:w-1/2 px-3 py-2 border rounded"
          required
        />
        <input
          type="text"
          name="type"
          value={newBusiness.type}
          onChange={handleInputChange}
          placeholder="Giro comercial"
          className="w-full sm:w-1/2 px-3 py-2 border rounded"
          required
        />
      </div>
      {/* Tercera fila: Cuota y Agente asignado */}
      <div className="flex flex-col sm:flex-row sm:space-x-2">
        <input
          type="number"
          name="quota"
          value={newBusiness.quota}
          onChange={handleInputChange}
          placeholder="Cuota"
          className="w-full sm:w-1/2 px-3 py-2 border rounded"
          required
        />
        <select
          name="agentId"
          value={newBusiness.agentId}
          onChange={handleInputChange}
          className="w-full sm:w-1/2 px-3 py-2 border rounded"
        >
          <option value="">Seleccionar Agente</option>
          {Object.keys(agentMapping).map((agentId) => (
            <option key={agentId} value={agentId}>
              {agentMapping[agentId]}
            </option>
          ))}
        </select>
      </div>
      {/* Horario */}
      <div className="space-y-2">
        <div>
          <span className="text-gray-700 block mb-1 text-sm">
            Días de apertura:
          </span>
          <div className="flex flex-wrap">
            {daysOfWeek.map((day) => (
              <label key={day} className="mr-2 flex items-center text-sm">
                <input
                  type="checkbox"
                  name="days"
                  value={day}
                  checked={newBusiness.schedule?.days?.includes(day) || false}
                  onChange={(e) => {
                    let newDays = newBusiness.schedule?.days
                      ? [...newBusiness.schedule.days]
                      : [];
                    if (e.target.checked) {
                      if (!newDays.includes(day)) {
                        newDays.push(day);
                      }
                    } else {
                      newDays = newDays.filter((d) => d !== day);
                    }
                    handleScheduleChange("days", newDays);
                  }}
                  className="mr-1"
                />
                {day}
              </label>
            ))}
          </div>
        </div>
        <div className="flex flex-col sm:flex-row sm:space-x-2">
          {/** 
           * CAMBIO: Renombramos 'opening' -> 'openingTime'
           */}
          <input
            type="time"
            name="openingTime"
            value={newBusiness.schedule?.openingTime || ""}
            onChange={(e) => handleScheduleChange("openingTime", e.target.value)}
            placeholder="Apertura"
            className="w-full sm:w-1/2 px-3 py-2 border rounded"
          />
          {/**
           * CAMBIO: Renombramos 'closing' -> 'closingTime'
           */}
          <input
            type="time"
            name="closingTime"
            value={newBusiness.schedule?.closingTime || ""}
            onChange={(e) => handleScheduleChange("closingTime", e.target.value)}
            placeholder="Cierre"
            className="w-full sm:w-1/2 px-3 py-2 border rounded"
          />
        </div>
      </div>
      {/* Botones */}
      <div className="flex justify-end space-x-2 mt-4">
        <button
          type="button"
          onClick={handleCancel}
          className="px-4 py-2 rounded border text-sm"
        >
          Cancelar
        </button>
        <button
          type="submit"
          className="px-4 py-2 rounded bg-blue-500 text-white text-sm"
        >
          Guardar
        </button>
      </div>
    </form>
  );
}

/** Componente SwitchButton para cambiar el estado del negocio */
function SwitchButton({ isActive, onToggle }) {
  return (
    <button
      onClick={onToggle}
      className={`relative inline-flex items-center h-6 rounded-full w-11 transition-colors focus:outline-none ${
        isActive ? "bg-blue-600" : "bg-gray-300"
      }`}
    >
      <span
        className={`inline-block w-4 h-4 transform bg-white rounded-full transition-transform ${
          isActive ? "translate-x-6" : "translate-x-1"
        }`}
      />
    </button>
  );
}

const BusinessesPage = () => {
  const db = getFirestore();
  const auth = getAuth();
  const user = auth.currentUser;
  const userId = user ? user.uid : null;

  // Estado inicial para el negocio
  // CAMBIO: usamos openingTime y closingTime en lugar de opening/closing
  const initialBusinessState = {
    name: "",
    address: "",
    location: "",
    phone: "",
    owner: "",
    type: "",
    quota: 0,
    agentId: "",
    creatorId: userId || "unknown",
    createdAt: null,
    status: "activo",
    qrUrl: "",
    schedule: {
      days: [],
      openingTime: "",
      closingTime: "",
    },
  };

  // Estados principales
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [currentStep, setCurrentStep] = useState(1);
  const [newBusinesses, setNewBusinesses] = useState([]);
  const [newBusiness, setNewBusiness] = useState(initialBusinessState);
  const [isEditing, setIsEditing] = useState(false);
  const [alert, setAlert] = useState(null);
  const [searchQuery, setSearchQuery] = useState("");
  const [agentMapping, setAgentMapping] = useState({});
  const [openDropdownId, setOpenDropdownId] = useState(null);
  // Estado para editar el agente asignado directamente en la tabla
  const [editingAgentBusinessId, setEditingAgentBusinessId] = useState(null);
  // Estado local para el valor seleccionado en el select
  const [selectedAgentValue, setSelectedAgentValue] = useState("");

  // Agregamos paginación
  const [currentPage, setCurrentPage] = useState(1);
  const itemsPerPage = 10;

  // Funciones para el registro multi-step (no se usan en edición)
  const handleNextStep = () => {
    if (currentStep < 2) setCurrentStep(currentStep + 1);
  };

  const handlePreviousStep = () => {
    if (currentStep > 1) setCurrentStep(currentStep - 1);
  };

  const detectLocation = () => {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          const { latitude, longitude } = position.coords;
          setNewBusiness({
            ...newBusiness,
            location: `Lat: ${latitude}, Lng: ${longitude}`,
          });
        },
        (error) => {
          console.error("Error al obtener ubicación:", error);
        }
      );
    } else {
      alert("La geolocalización no está soportada en este navegador.");
    }
  };

  // Actualizar horario
  // Solo renombramos fields a openingTime y closingTime en lugar de opening y closing
  const handleScheduleChange = (field, value) => {
    setNewBusiness((prev) => ({
      ...prev,
      schedule: { ...prev.schedule, [field]: value },
    }));
  };

  // Función para descargar QR
  const downloadQR = (qrUrl, name) => {
    const link = document.createElement("a");
    link.href = qrUrl;
    link.download = `${name}_QR.png`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  // Función para descargar el padrón completo de negocios en Excel
  const handleDownloadAllBusinesses = () => {
    if (newBusinesses.length === 0) {
      alert("No se encontraron negocios.");
      return;
    }
    const data = newBusinesses.map((biz) => {
      return {
        ID: biz.id,
        Nombre: biz.name || "Sin nombre",
        Dirección: biz.address || "No disponible",
        Teléfono: biz.phone || "No disponible",
        Propietario: biz.owner || "No disponible",
        "Agente Asignado": agentMapping[biz.agentId] || "Sin asignar",
        Tipo: biz.type || "No disponible",
        Quota:
          biz.quota !== undefined && biz.quota !== null ? biz.quota : "Sin cuota",
        Estado: biz.status || "No disponible",
      };
    });

    const worksheet = XLSX.utils.json_to_sheet(data);
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, "Negocios");
    const currentDate = dayjs().format("DD-MM-YY");
    const fileName = `padron_completo_${currentDate}.xlsx`;
    XLSX.writeFile(workbook, fileName);
  };

  // Obtener negocios (carga inicial)
  const fetchBusinesses = useCallback(async () => {
    try {
      const querySnapshot = await getDocs(collection(db, "negocios"));
      const fetchedBusinesses = querySnapshot.docs.map((doc) => ({
        id: doc.id,
        ...doc.data(),
      }));
      setNewBusinesses(fetchedBusinesses);
    } catch (error) {
      console.error("Error al obtener negocios:", error);
    }
  }, [db]);

  useEffect(() => {
    fetchBusinesses();
  }, [fetchBusinesses]);

  // Suscripción en tiempo real para negocios
  useEffect(() => {
    const unsubscribe = onSnapshot(
      collection(db, "negocios"),
      (snapshot) => {
        const businesses = snapshot.docs.map((doc) => ({
          id: doc.id,
          ...doc.data(),
        }));
        setNewBusinesses(businesses);
      },
      (error) => {
        console.error("Error al obtener datos en tiempo real:", error);
      }
    );
    return () => unsubscribe();
  }, [db]);

  // Suscripción en tiempo real para agentes (usuarios con rol "Cobrador")
  useEffect(() => {
    const unsub = onSnapshot(collection(db, "users"), (snapshot) => {
      const mapping = {};
      snapshot.docs.forEach((docSnap) => {
        const data = docSnap.data();
        if (data.role === "Cobrador" && data.name) {
          mapping[docSnap.id] = data.name;
        }
      });
      setAgentMapping(mapping);
    });
    return () => unsub();
  }, [db]);

  // Manejar cambios en inputs simples
  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setNewBusiness({ ...newBusiness, [name]: value });
  };

  // Registrar negocio (modo creación, multi-step)
  const handleFormSubmit = async (e) => {
    if (e && e.preventDefault) e.preventDefault();
    try {
      const user = auth.currentUser;
      const userId = user ? user.uid : "unknown";
      const timestamp = new Date().toISOString();

      if (!newBusiness.schedule?.days || newBusiness.schedule.days.length === 0) {
        alert("Por favor selecciona al menos un día de apertura.");
        return;
      }

      const businessData = {
        ...newBusiness,
        createdAt: timestamp,
        creatorId: userId,
      };

      const docRef = await addDoc(collection(db, "negocios"), businessData);

      // Generar el QR (solo en creación)
      const canvas = document.createElement("canvas");
      canvas.width = 300;
      canvas.height = 400;
      const context = canvas.getContext("2d");

      const QRCode = require("qrcode");
      await QRCode.toCanvas(canvas, docRef.id, { width: 300 });

      const logoImage = new Image();
      logoImage.src = require("../assets/logoQr.png");
      logoImage.onload = async () => {
        const logoSize = 40;
        const logoX = (canvas.width - logoSize) / 2;
        const logoY = (300 - logoSize) / 2;
        context.fillStyle = "white";
        context.fillRect(logoX, logoY, logoSize, logoSize);
        context.drawImage(logoImage, logoX, logoY, logoSize, logoSize);

        const businessName = newBusiness.name?.trim() || "Nombre no disponible";
        context.fillStyle = "#861E3D";
        context.font = "bold 18px Arial";
        context.textAlign = "center";
        context.fillText(businessName, canvas.width / 2, 290);

        const qrBase64 = canvas.toDataURL("image/png");
        const storage = getStorage();
        const qrRef = ref(storage, `qr_codes/${docRef.id}.png`);
        await uploadString(qrRef, qrBase64.split(",")[1], "base64");
        const qrUrl = await getDownloadURL(qrRef);
        await updateDoc(docRef, { qrUrl });
        setNewBusiness((prev) => ({ ...prev, qrUrl }));
        setCurrentStep(3);
      };
    } catch (error) {
      console.error("Error al registrar negocio:", error);
    }
  };

  // Iniciar edición (modo edición)
  const handleEditBusiness = (business) => {
    setNewBusiness(business);
    setIsEditing(true);
    setIsModalOpen(true);
  };

  // Enviar formulario en modo edición
  const handleEditFormSubmit = async (e) => {
    if (e && e.preventDefault) e.preventDefault();
    try {
      const { id, name, owner, phone, type, quota, schedule, agentId } = newBusiness;
      const dataToUpdate = {
        name,
        owner,
        phone,
        type,
        quota,
        agentId,
        schedule,
        updatedAt: new Date().toISOString(),
      };
      await updateDoc(doc(db, "negocios", id), dataToUpdate);
      setAlert({
        type: "success",
        message: "Negocio actualizado correctamente",
      });
      setNewBusiness(initialBusinessState);
      setIsModalOpen(false);
      setIsEditing(false);
    } catch (error) {
      console.error("Error actualizando negocio:", error);
      setAlert({
        type: "error",
        message: "Hubo un error actualizando el negocio",
      });
      setTimeout(() => setAlert(null), 3000);
    }
  };

  // Función para cambiar el estado del negocio
  const handleStatusChange = async (businessId, newStatus) => {
    try {
      const docRef = doc(db, "negocios", businessId);
      await updateDoc(docRef, { status: newStatus });
      setAlert({
        type: "success",
        message:
          newStatus === "activo"
            ? "El negocio se ha ACTIVADO con éxito"
            : "El negocio se ha DESACTIVADO con éxito",
      });
      setTimeout(() => setAlert(null), 3000);
    } catch (error) {
      console.error("Error al actualizar estado:", error);
      setAlert({
        type: "error",
        message: "Hubo un error al cambiar el estado.",
      });
      setTimeout(() => setAlert(null), 3000);
    }
  };

  // Función para actualizar el agente asignado desde la tabla
  const handleAgentChange = async (businessId, newAgentId) => {
    try {
      const docRef = doc(db, "negocios", businessId);
      await updateDoc(docRef, {
        agentId: newAgentId,
        updatedAt: new Date().toISOString(),
      });
      setAlert({
        type: "success",
        message: "Agente actualizado correctamente",
      });
      setEditingAgentBusinessId(null);
    } catch (error) {
      console.error("Error actualizando agente:", error);
      setAlert({
        type: "error",
        message: "Hubo un error actualizando el agente.",
      });
      setTimeout(() => setAlert(null), 3000);
    }
  };

  // Filtrar negocios según la búsqueda
  const filteredBusinesses = newBusinesses.filter((business) => {
    const query = searchQuery.toLowerCase();
    return (
      (business.name && business.name.toLowerCase().includes(query)) ||
      (business.owner && business.owner.toLowerCase().includes(query)) ||
      (business.type && business.type.toLowerCase().includes(query)) ||
      (business.address && business.address.toLowerCase().includes(query))
    );
  });

  // Paginación
  const totalPages = Math.ceil(filteredBusinesses.length / itemsPerPage);
  if (currentPage > totalPages && totalPages > 0) {
    setCurrentPage(1);
  }
  const paginatedBusinesses = filteredBusinesses.slice(
    (currentPage - 1) * itemsPerPage,
    currentPage * itemsPerPage
  );

  return (
    <div className="container mx-auto p-4 min-h-screen">
      <h1 className="text-2xl font-bold mb-4">Lista de Negocios</h1>

      {alert && (
        <div
          className={`mb-4 p-3 rounded border text-center ${
            alert.type === "success"
              ? "bg-green-100 border-green-400 text-green-700"
              : "bg-red-100 border-red-400 text-red-700"
          }`}
        >
          {alert.message}
        </div>
      )}

      {/* Botón de registro, buscador y botón para descargar todos los negocios */}
      <div className="flex flex-col md:flex-row justify-between items-center mb-4 space-y-2 md:space-y-0">
        <div className="flex items-center space-x-2">
          <button
            className="bg-blue-500 text-white px-4 py-2 rounded hover:bg-blue-600"
            onClick={() => {
              setNewBusiness(initialBusinessState);
              setIsEditing(false);
              setCurrentStep(1);
              setIsModalOpen(true);
            }}
          >
            Registrar Negocio
          </button>
          <button
            onClick={handleDownloadAllBusinesses}
            className="bg-green-500 text-white px-4 py-2 rounded hover:bg-green-600"
          >
            Descargar Padrón Completo
          </button>
        </div>
        <input
          type="text"
          placeholder="Buscar por nombre, propietario, tipo..."
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          className="w-full md:w-1/3 px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
        />
      </div>

      {/* Tabla de negocios */}
      <table className="w-full table-auto bg-white shadow-md rounded-lg text-sm">
        <thead className="bg-gray-200 text-gray-700 uppercase">
          <tr>
            <th className="py-2 px-2 text-left">Nombre</th>
            <th className="py-2 px-2 text-left">Ubicación</th>
            <th className="py-2 px-2 text-left">Teléfono</th>
            <th className="py-2 px-2 text-left">Propietario</th>
            <th className="py-2 px-2 text-left">Agente Asignado</th>
            <th className="py-2 px-2 text-left">Tipo</th>
            <th className="py-2 px-2 text-left">Cuota</th>
            <th className="py-2 px-2 text-left">Estado</th>
            <th className="py-2 px-2 text-center">Acciones</th>
          </tr>
        </thead>
        <tbody className="text-gray-600">
          {paginatedBusinesses.length > 0 ? (
            paginatedBusinesses.map((business, index) => (
              <tr
                key={business.id || index}
                className="border-b hover:bg-gray-100"
              >
                <td className="py-2 px-2 break-words">{business.name}</td>
                <td className="py-2 px-2 break-words">
                  {business.address || "No disponible"}
                </td>
                <td className="py-2 px-2 break-words">{business.phone}</td>
                <td className="py-2 px-2 break-words">{business.owner}</td>
                <td className="py-2 px-2 break-words">
                  {editingAgentBusinessId === business.id ? (
                    <select
                      value={selectedAgentValue}
                      onChange={(e) => setSelectedAgentValue(e.target.value)}
                      onBlur={async () => {
                        await handleAgentChange(business.id, selectedAgentValue);
                      }}
                      className="px-2 py-1 border rounded"
                      autoFocus
                    >
                      <option value="">Seleccionar Agente</option>
                      {Object.keys(agentMapping).map((agentId) => (
                        <option key={agentId} value={agentId}>
                          {agentMapping[agentId]}
                        </option>
                      ))}
                    </select>
                  ) : (
                    <span
                      className="cursor-pointer hover:underline"
                      onClick={() => {
                        setSelectedAgentValue(business.agentId);
                        setEditingAgentBusinessId(business.id);
                      }}
                    >
                      {agentMapping[business.agentId] || "N/A"}
                    </span>
                  )}
                </td>
                <td className="py-2 px-2 break-words">{business.type}</td>
                <td className="py-2 px-2 break-words">
                  ${business.quota || "0.00"}
                </td>
                <td className="py-2 px-2">
                  <SwitchButton
                    isActive={business.status === "activo"}
                    onToggle={() =>
                      handleStatusChange(
                        business.id,
                        business.status === "activo" ? "inactivo" : "activo"
                      )
                    }
                  />
                </td>
                <td className="py-2 px-2 text-center relative">
                  <button
                    className="bg-gray-700 text-white px-2 py-1 rounded hover:bg-gray-800"
                    onClick={() =>
                      setOpenDropdownId(
                        openDropdownId === business.id ? null : business.id
                      )
                    }
                  >
                    Acciones
                  </button>
                  {openDropdownId === business.id && (
                    <div className="absolute right-0 mt-1 w-40 bg-white border rounded shadow-lg z-10">
                      {business.qrUrl ? (
                        <button
                          className="block w-full text-left px-3 py-2 hover:bg-gray-200 text-sm"
                          onClick={() => {
                            downloadQR(business.qrUrl, business.name);
                            setOpenDropdownId(null);
                          }}
                        >
                          Descargar QR
                        </button>
                      ) : (
                        <button
                          className="block w-full text-left px-3 py-2 text-gray-400 text-sm cursor-not-allowed"
                          disabled
                        >
                          QR No disponible
                        </button>
                      )}
                      <button
                        className="block w-full text-left px-3 py-2 hover:bg-gray-200 text-sm"
                        onClick={() => {
                          handleEditBusiness(business);
                          setOpenDropdownId(null);
                        }}
                      >
                        Editar
                      </button>
                    </div>
                  )}
                </td>
              </tr>
            ))
          ) : (
            <tr>
              <td
                colSpan="9"
                className="text-center py-2 text-gray-500 italic"
              >
                No hay negocios disponibles.
              </td>
            </tr>
          )}
        </tbody>
      </table>

      {/* Controles de paginación */}
      {totalPages > 1 && (
        <div className="flex justify-center items-center mt-4 space-x-4">
          <button
            onClick={() => setCurrentPage((prev) => Math.max(prev - 1, 1))}
            className="px-3 py-1 bg-gray-300 rounded disabled:opacity-50"
            disabled={currentPage === 1}
          >
            Anterior
          </button>
          <span className="text-sm">
            Página {currentPage} de {totalPages}
          </span>
          <button
            onClick={() => setCurrentPage((prev) => Math.min(prev + 1, totalPages))}
            className="px-3 py-1 bg-gray-300 rounded disabled:opacity-50"
            disabled={currentPage === totalPages}
          >
            Siguiente
          </button>
        </div>
      )}

      {/* Modal para registro/edición */}
      {isModalOpen && (
        <div
          className="fixed inset-0 bg-gray-600 bg-opacity-50 flex justify-center items-center z-50"
          onClick={(e) => {
            if (e.target.classList.contains("bg-gray-600")) {
              setIsModalOpen(false);
              setIsEditing(false);
              setNewBusiness(initialBusinessState);
            }
          }}
        >
          <div className="bg-white p-6 rounded shadow-md w-[800px] relative">
            <button
              type="button"
              onClick={() => {
                setIsModalOpen(false);
                setIsEditing(false);
                setNewBusiness(initialBusinessState);
              }}
              className="absolute top-4 right-4 text-gray-500 hover:text-gray-700"
            >
              <FaTimes size={20} />
            </button>
            {isEditing ? (
              <BusinessEditForm
                newBusiness={newBusiness}
                handleInputChange={handleInputChange}
                handleFormSubmit={handleEditFormSubmit}
                handleCancel={() => {
                  setIsModalOpen(false);
                  setIsEditing(false);
                  setNewBusiness(initialBusinessState);
                }}
                agentMapping={agentMapping}
                handleScheduleChange={handleScheduleChange}
              />
            ) : (
              <BusinessForm
                newBusiness={newBusiness}
                setNewBusiness={setNewBusiness}
                handleInputChange={handleInputChange}
                handleNextStep={handleNextStep}
                handlePreviousStep={handlePreviousStep}
                detectLocation={detectLocation}
                handleFormSubmit={handleFormSubmit}
                currentStep={currentStep}
                handleCancel={() => {
                  setIsModalOpen(false);
                  setNewBusiness(initialBusinessState);
                }}
                isEditing={isEditing}
              />
            )}
          </div>
        </div>
      )}
    </div>
  );
};

export default BusinessesPage;
