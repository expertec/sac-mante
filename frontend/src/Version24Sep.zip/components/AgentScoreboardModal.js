// AgentScoreboardModal.js
import React, { useState, useCallback } from "react";
import dayjs from "dayjs";
import timezone from "dayjs/plugin/timezone";
import "dayjs/locale/es";
import { jsPDF } from "jspdf";
import { FaTimes } from "react-icons/fa";

dayjs.extend(timezone);
dayjs.locale("es");

const AgentScoreboardModal = ({ agent, payments, onClose }) => {
  // Período por defecto: inicio es 1 día antes y fin es el día actual
  const defaultStart = dayjs().tz("America/Mexico_City").subtract(1, "day").format("YYYY-MM-DD");
  const defaultEnd = dayjs().tz("America/Mexico_City").format("YYYY-MM-DD");

  const [periodStart, setPeriodStart] = useState(defaultStart);
  const [periodEnd, setPeriodEnd] = useState(defaultEnd);
  const [downloadLoading, setDownloadLoading] = useState(false);
  const [downloadError, setDownloadError] = useState(null);
  const [progress, setProgress] = useState(0);
  const [downloadStatus, setDownloadStatus] = useState("");

  // Función auxiliar para convertir un Blob a DataURL
  const blobToDataURL = (blob) => {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onloadend = () => resolve(reader.result);
      reader.onerror = reject;
      reader.readAsDataURL(blob);
    });
  };

  // Función para comprimir imagen
  const compressImage = async (dataUrl, quality = 0.7) => {
    return new Promise((resolve, reject) => {
      const img = new Image();
      img.onload = () => {
        const canvas = document.createElement("canvas");
        canvas.width = img.width;
        canvas.height = img.height;
        const ctx = canvas.getContext("2d");
        ctx.drawImage(img, 0, 0);
        const compressedDataUrl = canvas.toDataURL("image/jpeg", quality);
        resolve(compressedDataUrl);
      };
      img.onerror = reject;
      img.src = dataUrl;
    });
  };

  // Función para obtener dimensiones de imagen
  const getImageDimensions = (dataUrl) => {
    return new Promise((resolve, reject) => {
      const img = new Image();
      img.onload = () => resolve({ width: img.width, height: img.height });
      img.onerror = reject;
      img.src = dataUrl;
    });
  };

  // Función para descargar recibos en PDF
  const handleDownloadReceipts = useCallback(async () => {
    if (!periodStart || !periodEnd) {
      setDownloadError("Debe seleccionar ambas fechas.");
      return;
    }
    setDownloadError(null);
    setDownloadLoading(true);
    setProgress(0);
    setDownloadStatus("Descargando recibos...");

    try {
      // Construimos las fechas directamente desde los inputs
      const startDate = dayjs.tz(periodStart, "America/Mexico_City");
      const endDate = dayjs.tz(periodEnd, "America/Mexico_City").endOf("day");

      // Filtrar los pagos para el agente en el período seleccionado
      const filteredPayments = payments.filter((p) => {
        const paymentDate = dayjs(p.paymentDate).tz("America/Mexico_City");
        return (
          p.agentId === agent.id &&
          paymentDate.isBetween(startDate, endDate, null, "[]") &&
          p.receiptUrl
        );
      });

      if (filteredPayments.length === 0) {
        setDownloadError("No se encontraron recibos en el período seleccionado.");
        setDownloadLoading(false);
        return;
      }

      const imagesData = [];
      let i = 0;
      for (const payment of filteredPayments) {
        try {
          const response = await fetch(payment.receiptUrl);
          if (!response.ok) {
            console.error(`Error al descargar la imagen: ${payment.receiptUrl}`, response);
            continue;
          }
          const blob = await response.blob();
          let dataUrl = await blobToDataURL(blob);
          dataUrl = await compressImage(dataUrl, 0.7);
          imagesData.push({ dataUrl, format: "JPEG" });
        } catch (err) {
          console.error(`Error al procesar el recibo: ${payment.receiptUrl}`, err);
        }
        i++;
        setProgress(Math.round((i / filteredPayments.length) * 100));
      }

      if (imagesData.length === 0) {
        setDownloadError("No se pudieron descargar recibos válidos en el período seleccionado.");
        setDownloadLoading(false);
        return;
      }

      setDownloadStatus("Generando PDF...");
      const pdf = new jsPDF();
      const pageWidth = pdf.internal.pageSize.getWidth();
      const pageHeight = pdf.internal.pageSize.getHeight();
      const margin = 10;
      const headerHeight = 15;
      const cellWidth = (pageWidth - margin * 3) / 2;
      const cellHeight = (pageHeight - margin * 3 - headerHeight) / 2;

      const addHeader = () => {
        pdf.setFontSize(12);
        pdf.setTextColor(0, 0, 0);
        const headerText = `${agent.name} | Período: ${periodStart} a ${periodEnd}`;
        pdf.text(headerText, pageWidth / 2, margin + 7, { align: "center" });
      };

      for (let j = 0; j < imagesData.length; j += 4) {
        if (j > 0) pdf.addPage();
        addHeader();
        const cellsStartY = margin + headerHeight + margin;
        const group = imagesData.slice(j, j + 4);
        for (let index = 0; index < group.length; index++) {
          const img = group[index];
          const col = index % 2;
          const row = Math.floor(index / 2);
          const cellX = margin + col * (cellWidth + margin);
          const cellY = cellsStartY + row * (cellHeight + margin);
          const { width: imgWidth, height: imgHeight } = await getImageDimensions(img.dataUrl);
          const scale = Math.min(cellWidth / imgWidth, cellHeight / imgHeight);
          const imgW = imgWidth * scale;
          const imgH = imgHeight * scale;
          const x = cellX + (cellWidth - imgW) / 2;
          const y = cellY + (cellHeight - imgH) / 2;
          pdf.addImage(img.dataUrl, img.format, x, y, imgW, imgH);
        }
      }

      setProgress(100);
      setDownloadStatus("PDF generado, iniciando descarga...");
      pdf.save(`recibos_${agent.id}_${periodStart}_${periodEnd}.pdf`);
      setDownloadStatus("Descarga iniciada.");
    } catch (error) {
      console.error(error);
      setDownloadError("Ocurrió un error al generar el PDF de recibos.");
    }
    setDownloadLoading(false);
  }, [agent.id, payments, periodStart, periodEnd]);

  return (
    <div className="fixed inset-0 flex items-center justify-center bg-gray-900 bg-opacity-75 z-50 p-4">
      <div className="bg-white rounded-lg shadow-lg w-full max-w-4xl max-h-[90vh] overflow-y-auto">
        {/* Encabezado */}
        <div className="sticky top-0 z-10 bg-white border-b px-6 py-4 flex justify-between items-center">
          <h2 className="text-3xl font-bold text-gray-800">Descargar PDF</h2>
          <button onClick={onClose} className="text-gray-500 hover:text-gray-700">
            <FaTimes size={24} />
          </button>
        </div>

        <div className="p-6">
          {/* Selección de período */}
          <div className="mb-6">
            <h3 className="text-xl font-semibold text-gray-800 mb-2">Selecciona un período</h3>
            <div className="flex space-x-4">
              <div>
                <label className="block text-gray-700">Inicio</label>
                <input
                  type="date"
                  value={periodStart}
                  onChange={(e) => setPeriodStart(e.target.value)}
                  className="mt-1 p-2 border rounded"
                />
              </div>
              <div>
                <label className="block text-gray-700">Fin</label>
                <input
                  type="date"
                  value={periodEnd}
                  onChange={(e) => setPeriodEnd(e.target.value)}
                  className="mt-1 p-2 border rounded"
                />
              </div>
            </div>
          </div>

          {/* Botón para descargar PDF */}
          <div className="mb-6">
            <button
              onClick={handleDownloadReceipts}
              disabled={downloadLoading || !periodStart || !periodEnd}
              className="w-full bg-blue-500 text-white py-2 px-4 rounded hover:bg-blue-600"
            >
              {downloadLoading ? "Generando PDF..." : "Descargar Recibos"}
            </button>
            {downloadLoading && (
              <div className="mt-2">
                <p>Progreso: {progress}%</p>
                <div className="w-full bg-gray-300 rounded">
                  <div
                    className="bg-blue-500 text-xs leading-none py-1 text-center text-white rounded"
                    style={{ width: `${progress}%` }}
                  >
                    {progress}%
                  </div>
                </div>
                {downloadStatus && <p className="mt-2 text-sm text-gray-700">{downloadStatus}</p>}
              </div>
            )}
            {downloadError && <p className="mt-2 text-red-500">{downloadError}</p>}
          </div>
        </div>
      </div>
    </div>
  );
};

export default React.memo(AgentScoreboardModal);
