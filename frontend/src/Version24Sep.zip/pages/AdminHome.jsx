// AdminHomeOptimized.jsx
import React, { useState, useEffect, useMemo, useCallback } from "react";

import { getFirestore, collection, onSnapshot, query, orderBy } from "firebase/firestore";

import { jsPDF } from "jspdf";
import "jspdf-autotable";
import dayjs from "dayjs";
import customParseFormat from "dayjs/plugin/customParseFormat";
import "dayjs/locale/es";




import bgPdf from "../assets/bgPdf.png";

dayjs.locale("es");
dayjs.extend(customParseFormat);

function numberToSpanish(n) {
  const unidades = ["", "uno", "dos", "tres", "cuatro", "cinco", "seis", "siete", "ocho", "nueve"];
  const especiales = ["diez", "once", "doce", "trece", "catorce", "quince", "dieciséis", "diecisiete", "dieciocho", "diecinueve"];
  const decenas = ["", "", "veinte", "treinta", "cuarenta", "cincuenta", "sesenta", "setenta", "ochenta", "novecientos"];
  const centenas = ["", "cien", "doscientos", "trescientos", "cuatrocientos", "quinientos", "seiscientos", "setecientos", "ochocientos", "novecientos"];

  if (n < 10) return unidades[n];
  else if (n >= 10 && n < 20) return especiales[n - 10];
  else if (n < 100) {
    const dec = Math.floor(n / 10);
    const uni = n % 10;
    if (n === 20) return "veinte";
    else if (n < 30) return "veinti" + unidades[uni];
    else return decenas[dec] + (uni > 0 ? " y " + unidades[uni] : "");
  } else if (n < 1000) {
    const cent = Math.floor(n / 100);
    const rest = n % 100;
    if (n === 100) return "cien";
    else return (cent > 1 ? centenas[cent] : "ciento") + (rest > 0 ? " " + numberToSpanish(rest) : "");
  } else if (n < 1000000) {
    const miles = Math.floor(n / 1000);
    const rest = n % 1000;
    const milesText = miles === 1 ? "mil" : numberToSpanish(miles) + " mil";
    return milesText + (rest > 0 ? " " + numberToSpanish(rest) : "");
  } else {
    return n.toString();
  }
}

function convertNumberToText(amount) {
  const entero = Math.floor(amount);
  const decimales = Math.round((amount - entero) * 100);
  const enteroText = numberToSpanish(entero);
  return `${enteroText.toUpperCase()} CON ${decimales < 10 ? "0" + decimales : decimales}/100`;
}

/**
 * Calendario para ingresos diarios.
 */
function Calendar({ year, month, paymentsData }) {
  const currentDate = new Date(year, month);
  const monthName = currentDate.toLocaleString("es-ES", { month: "long", year: "numeric" });
  const firstDayOfMonth = new Date(year, month, 1).getDay();
  const daysInMonth = new Date(year, month + 1, 0).getDate();
  const todayLocal = new Date();
  const daysOfWeek = ["Domingo", "Lunes", "Martes", "Miércoles", "Jueves", "Viernes", "Sábado"];

  const daysArray = useMemo(() => {
    return Array.from({ length: daysInMonth }, (_, index) => {
      const dayDate = new Date(year, month, index + 1);
      const dayKey = dayjs(dayDate).format("YYYY-MM-DD");
      const dayPayments = paymentsData[dayKey] || [];
      return { date: dayDate, payments: dayPayments };
    });
  }, [year, month, daysInMonth, paymentsData]);

  return (
    <div className="bg-white shadow rounded-lg overflow-hidden">
      <div className="px-4 py-2 bg-gray-100 border-b">
        <h2 className="text-lg font-semibold text-gray-700">{monthName}</h2>
      </div>
      <div className="grid grid-cols-7 gap-1 text-center text-sm font-semibold text-gray-600 border-b">
        {daysOfWeek.map((day) => (
          <div key={day} className="py-2 uppercase">
            {day.slice(0, 3)}
          </div>
        ))}
      </div>
      <div className="grid grid-cols-7 gap-1">
        {Array.from({ length: firstDayOfMonth }).map((_, i) => (
          <div key={i} className="py-2" />
        ))}
        {daysArray.map(({ date, payments }, i) => {
          const isToday = date.toDateString() === todayLocal.toDateString();
          const totalForDay = payments.reduce(
            (sum, p) => sum + (p.netAmount !== undefined ? p.netAmount : p.amount),
            0
          );
          const infoText = payments.length > 0
            ? `Pagos: ${payments.length} (${new Intl.NumberFormat("es-MX", {
                style: "currency",
                currency: "MXN",
              }).format(totalForDay)})`
            : "Sin pagos";
          let bgColor = "bg-gray-50 border-gray-200";
          if (isToday) bgColor = "bg-blue-100 border-blue-400";
          else if (payments.length > 0) bgColor = "bg-green-100 border-green-400";

          return (
            <div key={i} className={`p-2 h-24 flex flex-col justify-between rounded border ${bgColor}`}>
              <div className="text-right text-xs font-semibold text-gray-500">
                {isToday ? "Hoy" : date.getDate()}
              </div>
              <div className="text-sm text-gray-700">{infoText}</div>
            </div>
          );
        })}
      </div>
    </div>
  );
};

const AdminHome = () => {
  const db = getFirestore();

  // Estados generales
  const [allCobros, setAllCobros] = useState([]);
  const [activeBusinesses, setActiveBusinesses] = useState(0);
  const [inactiveBusinesses, setInactiveBusinesses] = useState(0);
  const [agentMapping, setAgentMapping] = useState({});
  const [businessMapping, setBusinessMapping] = useState({});
  const [reports, setReports] = useState([]);

  // Estados para fechas y vista
  const [selectedYear, setSelectedYear] = useState(new Date().getFullYear());
  const [selectedMonth, setSelectedMonth] = useState(new Date().getMonth());
  const [paymentsData, setPaymentsData] = useState({});
  const [selectedReportDate, setSelectedReportDate] = useState(dayjs().format("YYYY-MM-DD"));
  const [activeView, setActiveView] = useState("diarios");

  // Estados para filtros y paginación
  const [historicosPage, setHistoricosPage] = useState(1);
  const [reportesPage, setReportesPage] = useState(1);
  const [historicosFilter, setHistoricosFilter] = useState("");
  const [reportesFilter, setReportesFilter] = useState("");

  const [negociosFilterDate, setNegociosFilterDate] = useState(dayjs().format("YYYY-MM-DD"));
  const [negociosPage, setNegociosPage] = useState(1);
  const [negociosFilterStatus, setNegociosFilterStatus] = useState("todos");

  // Estados de carga para cada suscripción
  const [loadingCobros, setLoadingCobros] = useState(true);
  const [loadingUsers, setLoadingUsers] = useState(true);
  const [loadingNegocios, setLoadingNegocios] = useState(true);
  const [loadingReports, setLoadingReports] = useState(true);

  // Escuchar usuarios para agentMapping
  useEffect(() => {
    const unsub = onSnapshot(collection(db, "users"), (snapshot) => {
      const mapping = {};
      snapshot.docs.forEach((docSnap) => {
        const data = docSnap.data();
        if (data.role === "Cobrador" && data.name) {
          mapping[docSnap.id] = data.name;
        }
      });
      setAgentMapping(mapping);
      setLoadingUsers(false);
    });
    return () => unsub();
  }, [db]);

  // Actualizar selectedReportDate según mes/año
  useEffect(() => {
    const today = new Date();
    if (selectedYear === today.getFullYear() && selectedMonth === today.getMonth()) {
      setSelectedReportDate(dayjs(today).format("YYYY-MM-DD"));
    } else {
      setSelectedReportDate(dayjs(new Date(selectedYear, selectedMonth, 1)).format("YYYY-MM-DD"));
    }
  }, [selectedYear, selectedMonth]);

  const minDate = dayjs(new Date(selectedYear, selectedMonth, 1)).format("YYYY-MM-DD");
  const maxDate = dayjs(new Date(selectedYear, selectedMonth + 1, 0)).format("YYYY-MM-DD");

  const handleNextMonth = () => {
    let m = selectedMonth + 1;
    let y = selectedYear;
    if (m > 11) {
      m = 0;
      y += 1;
    }
    setSelectedMonth(m);
    setSelectedYear(y);
  };

  const handlePrevMonth = () => {
    let m = selectedMonth - 1;
    let y = selectedYear;
    if (m < 0) {
      m = 11;
      y -= 1;
    }
    setSelectedMonth(m);
    setSelectedYear(y);
  };

  // Escuchar cobros
  useEffect(() => {
    const unsub = onSnapshot(collection(db, "cobros"), (snapshot) => {
      const cobrosArr = [];
      snapshot.docs.forEach((docSnap) => {
        const data = docSnap.data();
        const paymentDate = data.date && data.date.toDate ? data.date.toDate() : new Date();
        const amount = data.netAmount !== undefined ? data.netAmount : parseFloat(data.amount || 0);
        cobrosArr.push({
          ...data,
          paymentDate,
          amount,
        });
      });
      setAllCobros(cobrosArr);
      setLoadingCobros(false);
    });
    return () => unsub();
  }, [db]);

  // Escuchar negocios para conteos y mapping
  useEffect(() => {
    const negociosRef = collection(db, "negocios");
    const unsubscribe = onSnapshot(negociosRef, (snapshot) => {
      let activeCount = 0;
      let inactiveCount = 0;
      const mapping = {};
      snapshot.docs.forEach((docSnap) => {
        const data = docSnap.data();
        if (data.status === "activo") activeCount++;
        else if (data.status === "inactivo") inactiveCount++;
        const schedule = data.schedule || {};
        const daysArray = Array.isArray(schedule.days) ? schedule.days : [];
        mapping[docSnap.id] = {
          businessName: data.name || "Sin negocio",
          phone: data.phone || "Sin teléfono",
          agentId: data.agentId,
          days: daysArray.length > 0 ? daysArray.join(", ") : "No especificado",
          daysArray: daysArray,
          openingTime: schedule.openingTime || "No especificado",
          closingTime: schedule.closingTime || "No especificado",
        };
      });
      setActiveBusinesses(activeCount);
      setInactiveBusinesses(inactiveCount);
      setBusinessMapping(mapping);
      setLoadingNegocios(false);
    });
    return () => unsubscribe();
  }, [db]);

// Escuchar reportes (ordenados por `date`)
// Escuchar reportes (ordenados por `date`)
useEffect(() => {
  const q = query(
    collection(db, "reportes"),
    orderBy("date", "desc")
  );
  const unsubscribe = onSnapshot(q, snapshot => {
    const temp = snapshot.docs.map(docSnap => {
      const data = docSnap.data();
      let createdDate;

      if (typeof data.date === "string") {
        // 1) Si es ISO (ej. "2025-02-10T18:39:55.19Z"), úsalo directamente:
        if (/^\d{4}-\d{2}-\d{2}T/.test(data.date)) {
          createdDate = new Date(data.date);
        } 
        // 2) Si es tu formato en español, parséalo:
        else {
          const raw = data.date.split(" UTC")[0]; // quita zona horaria
          const re = /(\d{1,2}) de (\w+) de (\d{4}),\s*(\d{1,2}):(\d{2}):(\d{2})\s*([ap]\.m\.)/i;
          const m = raw.match(re);
          if (m) {
            const [ , D, mes, YYYY, hh, mm, ss, ampm ] = m;
            const monthIdx = {
              enero:0, febrero:1, marzo:2, abril:3, mayo:4, junio:5,
              julio:6, agosto:7, septiembre:8, octubre:9, noviembre:10, diciembre:11
            }[mes.toLowerCase()] || 0;
            let H = parseInt(hh, 10);
            if (/p\.m\./i.test(ampm) && H < 12) H += 12;
            if (/a\.m\./i.test(ampm) && H === 12) H = 0;
            createdDate = new Date(
              parseInt(YYYY, 10),
              monthIdx,
              parseInt(D, 10),
              H,
              parseInt(mm, 10),
              parseInt(ss, 10)
            );
          } else {
            // fallback: intenta con Date() sobre la cadena entera
            createdDate = new Date(data.date);
          }
        }
      }
      // 3) Si más adelante migras a Timestamp de Firestore:
      else if (data.date?.toDate) {
        createdDate = data.date.toDate();
      }
      // 4) Ultimo recurso:
      else {
        createdDate = new Date();
      }

      return {
        id: docSnap.id,
        ...data,
        createdAt: createdDate,
      };
    });

    setReports(temp);
    setLoadingReports(false);
  });

  return () => unsubscribe();
}, [db]);




  // Calcular ingresos de hoy (useMemo)
  const todayPayments = useMemo(() => {
    const now = new Date();
    const startToday = new Date(now.getFullYear(), now.getMonth(), now.getDate(), 0, 0, 0);
    const endToday = new Date(now.getFullYear(), now.getMonth(), now.getDate(), 23, 59, 59);
    return allCobros.reduce((sum, c) => {
      if (c.paymentDate >= startToday && c.paymentDate <= endToday) {
        return sum + c.amount;
      }
      return sum;
    }, 0);
  }, [allCobros]);

  // Calcular ingresos del mes y agrupar pagos por día (useMemo)
  const { selectedMonthPayments, paymentsDataMemo } = useMemo(() => {
    const startMonth = new Date(selectedYear, selectedMonth, 1, 0, 0, 0);
    const endMonth = new Date(selectedYear, selectedMonth + 1, 0, 23, 59, 59);
    let sumMonth = 0;
    const map = {};
    allCobros.forEach((c) => {
      if (dayjs(c.paymentDate).isBetween(dayjs(startMonth), dayjs(endMonth), "day", "[]")) {
        sumMonth += c.amount;
        const dateKey = dayjs(c.paymentDate).format("YYYY-MM-DD");
        if (!map[dateKey]) {
          map[dateKey] = [];
        }
        map[dateKey].push(c);
      }
    });
    return { selectedMonthPayments: sumMonth, paymentsDataMemo: map };
  }, [allCobros, selectedYear, selectedMonth]);

  // Actualizar pagos agrupados
  useEffect(() => {
    setPaymentsData(paymentsDataMemo);
  }, [paymentsDataMemo]);

  // Función para descargar PDF (useCallback)
  const handleDownloadPDF = useCallback(() => {
    const dayPayments = paymentsData[selectedReportDate] || [];
    if (dayPayments.length === 0) {
      alert("No se encontraron cobros para la fecha seleccionada.");
      return;
    }
    const agentData = {};
    dayPayments.forEach((payment) => {
      const agentId = payment.agentId;
      const agentName = agentMapping[agentId] || "N/A";
      if (!agentData[agentName]) {
        agentData[agentName] = { sum: 0, folios: [] };
      }
      agentData[agentName].sum += payment.amount;
      if (payment.folio) {
        agentData[agentName].folios.push(payment.folio);
      }
    });
    const tableBody = Object.entries(agentData).map(([agent, data]) => [
      agent,
      new Intl.NumberFormat("es-MX", { style: "currency", currency: "MXN" }).format(data.sum),
      data.folios.join(", "),
    ]);
    const totalSum = Object.values(agentData).reduce((acc, data) => acc + data.sum, 0);
    tableBody.push([
      "TOTAL",
      new Intl.NumberFormat("es-MX", { style: "currency", currency: "MXN" }).format(totalSum),
      "",
    ]);
  
    const doc = new jsPDF("p", "mm", "a4");
    const pageWidth = doc.internal.pageSize.getWidth();
    const pageHeight = doc.internal.pageSize.getHeight();
    doc.addImage(bgPdf, "PNG", 0, 0, pageWidth, pageHeight);
    const marginSide = 10;
    const maxTitleWidth = pageWidth - marginSide * 2;
    const titleText = "RELACIÓN DE FOLIOS POR CONCEPTO DE COBRO POR USO DE VÍA PÚBLICA";
    doc.setFont("helvetica", "bold");
    doc.setFontSize(12);
    const titleLines = doc.splitTextToSize(titleText, maxTitleWidth);
    const lineHeight = 5;
    const computedTitleHeight = titleLines.length * lineHeight;
    const gapBetweenTitleAndTable = 10;
    const startY = 50;
    titleLines.forEach((line, index) => {
      doc.text(line, pageWidth / 2, startY + index * lineHeight, { align: "center" });
    });
    const tableStartY = startY + computedTitleHeight + gapBetweenTitleAndTable;
    const reportDate = dayjs(selectedReportDate).format("D MMM YYYY").toUpperCase();
    doc.setFont("helvetica", "normal");
    doc.setFontSize(10);
    doc.text(reportDate, pageWidth - 10, tableStartY - 5, { align: "right" });
    
    // Generar la tabla
    doc.autoTable({
      startY: tableStartY,
      head: [["Agente", "Total Cobrado", "Folios"]],
      body: tableBody,
      styles: { font: "helvetica", fontSize: 10, halign: "center" },
      headStyles: { fillColor: [220, 220, 220], textColor: 0, fontStyle: "bold", halign: "center" },
      columnStyles: { 1: { halign: "right" }, 2: { halign: "left" } },
      theme: "grid",
    });
  
    const finalY = doc.lastAutoTable.finalY || tableStartY;
    const signatureY = finalY + 20;
    const leftMargin = 60;
    const rightMargin = 60;
    doc.setLineWidth(0.5);
    doc.line(leftMargin, signatureY, pageWidth - rightMargin, signatureY);
    doc.setFont("helvetica", "normal");
    doc.setFontSize(10);
    doc.text("CP. MONICA LIZBETH REYES HERNANDEZ", pageWidth / 2, signatureY + 7, { align: "center" });
    doc.text("JEFA DE INGRESOS", pageWidth / 2, signatureY + 12, { align: "center" });
    doc.save(`Reporte_${selectedReportDate}.pdf`);
  }, [paymentsData, selectedReportDate, agentMapping]);

  // Cálculos para "Negocios sin Cobro" (mover hooks fuera de renderContent)
  const businessList = useMemo(
    () => Object.entries(businessMapping).map(([id, info]) => ({ id, ...info })),
    [businessMapping]
  );
  const filterDayStr = useMemo(
    () => dayjs(negociosFilterDate).format("YYYY-MM-DD"),
    [negociosFilterDate]
  );
  const businessesWithoutCobro = useMemo(() => {
    return businessList.filter((business) =>
      !allCobros.some((cobro) =>
        cobro.businessId === business.id &&
        dayjs(cobro.paymentDate).format("YYYY-MM-DD") === filterDayStr
      )
    );
  }, [businessList, allCobros, filterDayStr]);
  const businessesWithChip = useMemo(() => {
    return businessesWithoutCobro.map((business) => {
      const hasReporte = reports.some((r) =>
        r.businessId === business.id &&
        dayjs(r.createdAt).format("YYYY-MM-DD") === filterDayStr
      );
      const dayName = dayjs(negociosFilterDate).locale("es").format("dddd");
      const dayNameCapitalized = dayName.charAt(0).toUpperCase() + dayName.slice(1);
      const isClosed = !business.daysArray.includes(dayNameCapitalized);
      return { ...business, hasReporte, isClosed };
    });
  }, [businessesWithoutCobro, reports, negociosFilterDate]);
  const filteredBusinessesByStatus = useMemo(() => {
    if (negociosFilterStatus === "cerrado") {
      return businessesWithChip.filter((b) => b.isClosed);
    } else if (negociosFilterStatus === "conReporte") {
      return businessesWithChip.filter((b) => !b.isClosed && b.hasReporte);
    } else if (negociosFilterStatus === "sinReporte") {
      return businessesWithChip.filter((b) => !b.isClosed && !b.hasReporte);
    }
    return businessesWithChip;
  }, [businessesWithChip, negociosFilterStatus]);

  // Ordenar y filtrar históricos y reportes con useMemo (fuera de renderContent)
  const sortedCobros = useMemo(() => {
    return [...allCobros].sort((a, b) => b.paymentDate - a.paymentDate);
  }, [allCobros]);

  const filteredHistoricos = useMemo(() => {
    if (!historicosFilter) return sortedCobros;
    return sortedCobros.filter((c) =>
      dayjs(c.paymentDate).format("YYYY-MM-DD") === historicosFilter
    );
  }, [sortedCobros, historicosFilter]);

  const sortedReports = useMemo(() => {
    return [...reports].sort((a, b) => b.createdAt - a.createdAt);
  }, [reports]);

  const filteredReports = useMemo(() => {
    if (!reportesFilter) return sortedReports;
    return sortedReports.filter((r) =>
      dayjs(r.createdAt).format("YYYY-MM-DD") === reportesFilter
    );
  }, [sortedReports, reportesFilter]);

  // Si aún se están cargando algunas colecciones, muestra un spinner animado
  const isLoading = loadingCobros || loadingUsers || loadingNegocios || loadingReports;

  const renderContent = () => {
    if (activeView === "diarios") {
      return (
        <>
          <div className="flex items-center justify-between mb-4">
            <div>
              <button onClick={handlePrevMonth} className="mr-4 px-4 py-2 bg-gray-200 rounded hover:bg-gray-300">
                Mes Anterior
              </button>
              <button onClick={handleNextMonth} className="px-4 py-2 bg-gray-200 rounded hover:bg-gray-300">
                Mes Siguiente
              </button>
            </div>
            <div className="flex items-center gap-2">
              <input
                type="date"
                value={selectedReportDate}
                onChange={(e) => setSelectedReportDate(e.target.value)}
                min={minDate}
                max={maxDate}
                className="px-2 py-1 border rounded"
              />
              <button onClick={handleDownloadPDF} className="px-4 py-2 bg-blue-500 text-white rounded hover:bg-blue-600">
                Descargar PDF {dayjs(selectedReportDate).format("D MMM YYYY")}
              </button>
            </div>
          </div>
          <Calendar year={selectedYear} month={selectedMonth} paymentsData={paymentsData} />
          <div className="mt-4 bg-white shadow rounded p-4">
            <h2 className="text-lg font-semibold">Resumen del Día</h2>
            <p className="text-gray-700 mt-2">
              Ingresos de hoy:{" "}
              {new Intl.NumberFormat("es-MX", { style: "currency", currency: "MXN" }).format(todayPayments)}
            </p>
            <p className="text-gray-700 mt-2">
              Ingresos del mes:{" "}
              {new Intl.NumberFormat("es-MX", { style: "currency", currency: "MXN" }).format(selectedMonthPayments)}
            </p>
          </div>
        </>
      );
    } else if (activeView === "historicos") {
      const itemsPerPage = 10;
      const totalHistoricosPages = Math.ceil(filteredHistoricos.length / itemsPerPage);
      const historicosPaginated = filteredHistoricos.slice(
        (historicosPage - 1) * itemsPerPage,
        historicosPage * itemsPerPage
      );

      return (
        <div className="bg-white shadow rounded p-4 overflow-x-auto">
          <h2 className="text-lg font-semibold mb-4">Histórico de Ingresos</h2>
          <div className="mb-4 flex items-center">
            <label className="mr-2">Filtrar por día:</label>
            <input
              type="date"
              value={historicosFilter}
              onChange={(e) => {
                setHistoricosFilter(e.target.value);
                setHistoricosPage(1);
              }}
              className="px-2 py-1 border rounded"
            />
            {historicosFilter && (
              <button onClick={() => {
                setHistoricosFilter("");
                setHistoricosPage(1);
              }} className="ml-2 text-blue-600 underline">
                Limpiar filtro
              </button>
            )}
          </div>
          <table className="min-w-full text-sm">
            <thead>
              <tr className="bg-gray-200">
                <th className="py-2 px-4 border">Fecha</th>
                <th className="py-2 px-4 border">Agente</th>
                <th className="py-2 px-4 border">Total Cobrado</th>
                <th className="py-2 px-4 border">Crédito Aplicado</th>
                <th className="py-2 px-4 border">Monto Neto</th>
                <th className="py-2 px-4 border">Folio</th>
              </tr>
            </thead>
            <tbody>
              {historicosPaginated.map((c, i) => (
                <tr key={i} className="border-b">
                  <td className="py-2 px-4 border">
                    {dayjs(c.paymentDate).format("D MMM YYYY, h:mm A")}
                  </td>
                  <td className="py-2 px-4 border">
                    {agentMapping[c.agentId] || c.agentId || "Sin agente"}
                  </td>
                  <td className="py-2 px-4 border">
                    {new Intl.NumberFormat("es-MX", { style: "currency", currency: "MXN" }).format(
                      c.totalAmount || c.amount
                    )}
                  </td>
                  <td className="py-2 px-4 border">
                    {new Intl.NumberFormat("es-MX", { style: "currency", currency: "MXN" }).format(
                      c.appliedCredit || 0
                    )}
                  </td>
                  <td className="py-2 px-4 border">
                    {new Intl.NumberFormat("es-MX", { style: "currency", currency: "MXN" }).format(
                      c.netAmount !== undefined ? c.netAmount : c.amount
                    )}
                  </td>
                  <td className="py-2 px-4 border">{c.folio || "N/A"}</td>
                </tr>
              ))}
            </tbody>
          </table>
          <div className="flex justify-end items-center mt-4">
            <button
              onClick={() => setHistoricosPage(historicosPage - 1)}
              disabled={historicosPage === 1}
              className="px-3 py-1 border rounded mr-2"
            >
              Anterior
            </button>
            <span>
              Página {historicosPage} de {totalHistoricosPages}
            </span>
            <button
              onClick={() => setHistoricosPage(historicosPage + 1)}
              disabled={historicosPage === totalHistoricosPages}
              className="px-3 py-1 border rounded ml-2"
            >
              Siguiente
            </button>
          </div>
        </div>
      );
    } else if (activeView === "reportes") {
      const itemsPerPage = 10;
      const totalReportesPages = Math.ceil(filteredReports.length / itemsPerPage);
      const reportesPaginated = filteredReports.slice(
        (reportesPage - 1) * itemsPerPage,
        reportesPage * itemsPerPage
      );

      return (
        <div className="bg-white shadow rounded p-4 overflow-x-auto">
          <h2 className="text-lg font-semibold mb-4">Historial de Reportes</h2>
          <div className="mb-4 flex items-center">
            <label className="mr-2">Filtrar por día:</label>
            <input
              type="date"
              value={reportesFilter}
              onChange={(e) => {
                setReportesFilter(e.target.value);
                setReportesPage(1);
              }}
              className="px-2 py-1 border rounded"
            />
            {reportesFilter && (
              <button onClick={() => {
                setReportesFilter("");
                setReportesPage(1);
              }} className="ml-2 text-blue-600 underline">
                Limpiar filtro
              </button>
            )}
          </div>
          <table className="min-w-full text-sm">
            <thead>
              <tr className="bg-gray-200">
                <th className="py-2 px-4 border">Fecha</th>
                <th className="py-2 px-4 border">Agente</th>
                <th className="py-2 px-4 border">Negocio</th>
                <th className="py-2 px-4 border">Teléfono</th>
                <th className="py-2 px-4 border">Ubicación</th>
                <th className="py-2 px-4 border">Foto</th>
              </tr>
            </thead>
            <tbody>
              {reportesPaginated.map((report) => (
                <tr key={report.id} className="border-b">
                  <td className="py-2 px-4 border">
                    {dayjs(report.createdAt).format("D MMM YYYY, h:mm A")}
                  </td>
                  <td className="py-2 px-4 border">
                    {agentMapping[report.agentId] || report.agentId || "Sin agente"}
                  </td>
                  <td className="py-2 px-4 border">
                    {businessMapping[report.businessId]?.businessName || "Sin negocio"}
                  </td>
                  <td className="py-2 px-4 border">
                    {businessMapping[report.businessId]?.phone || "Sin teléfono"}
                  </td>
                  <td className="py-2 px-4 border">
                    {report.location ? `${report.location.Lat}, ${report.location.Lng}` : "Sin ubicación"}
                  </td>
                  <td className="py-2 px-4 border text-center">
                    {report.photoURL ? (
                      <button onClick={() => openPhotoModal(report.photoURL)} className="text-blue-600 underline">
                        Ver Imagen
                      </button>
                    ) : (
                      "Sin foto"
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
          <div className="flex justify-end items-center mt-4">
            <button
              onClick={() => setReportesPage(reportesPage - 1)}
              disabled={reportesPage === 1}
              className="px-3 py-1 border rounded mr-2"
            >
              Anterior
            </button>
            <span>
              Página {reportesPage} de {totalReportesPages}
            </span>
            <button
              onClick={() => setReportesPage(reportesPage + 1)}
              disabled={reportesPage === totalReportesPages}
              className="px-3 py-1 border rounded ml-2"
            >
              Siguiente
            </button>
          </div>
        </div>
      );
    } else if (activeView === "negociosSinCobro") {
      const itemsPerPage = 15;
      const totalNegociosPages = Math.ceil(filteredBusinessesByStatus.length / itemsPerPage);
      const paginatedBusinesses = filteredBusinessesByStatus.slice(
        (negociosPage - 1) * itemsPerPage,
        negociosPage * itemsPerPage
      );

      return (
        <div className="bg-white shadow rounded p-4 overflow-x-auto">
          <h2 className="text-lg font-semibold mb-4">
            Negocios sin cobro para el día {dayjs(negociosFilterDate).format("D MMM YYYY")}
          </h2>
          <div className="mb-4 flex items-center">
            <label className="mr-2">Filtrar por día:</label>
            <input
              type="date"
              value={negociosFilterDate}
              onChange={(e) => {
                setNegociosFilterDate(e.target.value);
                setNegociosPage(1);
              }}
              className="px-2 py-1 border rounded"
            />
          </div>
          <div className="mb-4 flex items-center">
            <label className="mr-2">Filtrar por estado:</label>
            <select
              value={negociosFilterStatus}
              onChange={(e) => {
                setNegociosFilterStatus(e.target.value);
                setNegociosPage(1);
              }}
              className="px-2 py-1 border rounded"
            >
              <option value="todos">Todos</option>
              <option value="cerrado">Cerrado</option>
              <option value="conReporte">Con Reporte</option>
              <option value="sinReporte">Sin Reporte</option>
            </select>
          </div>
          <p className="mb-4">
            Total de negocios sin cobro: {filteredBusinessesByStatus.length} | Negocios cerrados:{" "}
            {businessesWithChip.filter((b) => b.isClosed).length} | Con reporte:{" "}
            {businessesWithChip.filter((b) => !b.isClosed && b.hasReporte).length} | Sin reporte:{" "}
            {businessesWithChip.filter((b) => !b.isClosed && !b.hasReporte).length}
          </p>
          <table className="min-w-full text-sm">
            <thead>
              <tr className="bg-gray-200">
                <th className="py-2 px-4 border">Agente</th>
                <th className="py-2 px-4 border">Negocio</th>
                <th className="py-2 px-4 border">Teléfono</th>
                <th className="py-2 px-4 border">Reporte / Cerrado</th>
                <th className="py-2 px-4 border">Días</th>
                <th className="py-2 px-4 border">Horario</th>
              </tr>
            </thead>
            <tbody>
              {paginatedBusinesses.map((business) => (
                <tr key={business.id} className="border-b">
                  <td className="py-2 px-4 border">
                    {agentMapping[business.agentId] || "Sin agente"}
                  </td>
                  <td className="py-2 px-4 border">{business.businessName}</td>
                  <td className="py-2 px-4 border">{business.phone}</td>
                  <td className="py-2 px-4 border text-center">
                    {business.isClosed ? (
                      <span className="bg-red-300 text-red-800 px-2 py-1 rounded">
                        Cerrado
                      </span>
                    ) : business.hasReporte ? (
                      <span className="bg-yellow-300 text-yellow-900 px-2 py-1 rounded">
                        Reporte
                      </span>
                    ) : (
                      <span className="bg-gray-300 text-gray-800 px-2 py-1 rounded">
                        Sin Reporte
                      </span>
                    )}
                  </td>
                  <td className="py-2 px-4 border text-center">
                    <span className="bg-blue-200 text-blue-800 px-2 py-1 rounded">
                      {business.days}
                    </span>
                  </td>
                  <td className="py-2 px-4 border text-center">
                    <span className="bg-green-200 text-green-800 px-2 py-1 rounded">
                      Apertura: {business.openingTime} - Cierre: {business.closingTime}
                    </span>
                  </td>
                </tr>
              ))}
              {paginatedBusinesses.length === 0 && (
                <tr>
                  <td className="py-2 px-4 border" colSpan={6}>
                    Todos los negocios tienen cobro para este día.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
          <div className="flex justify-end items-center mt-4">
            <button
              onClick={() => setNegociosPage(negociosPage - 1)}
              disabled={negociosPage === 1}
              className="px-3 py-1 border rounded mr-2"
            >
              Anterior
            </button>
            <span>
              Página {negociosPage} de {totalNegociosPages}
            </span>
            <button
              onClick={() => setNegociosPage(negociosPage + 1)}
              disabled={negociosPage === totalNegociosPages}
              className="px-3 py-1 border rounded ml-2"
            >
              Siguiente
            </button>
          </div>
        </div>
      );
    }
    return null;
  };

  // Modal para foto
  const [selectedPhotoUrl, setSelectedPhotoUrl] = useState(null);
  const openPhotoModal = (url) => setSelectedPhotoUrl(url);
  const closePhotoModal = () => setSelectedPhotoUrl(null);

  // Si aún se están cargando datos, muestra un spinner con animación
  if (isLoading) {
    return (
      <div className="flex flex-col items-center justify-center h-screen">
        <svg
          className="animate-spin h-12 w-12 text-blue-500 mb-4"
          xmlns="http://www.w3.org/2000/svg"
          fill="none"
          viewBox="0 0 24 24"
        >
          <circle
            className="opacity-25"
            cx="12"
            cy="12"
            r="10"
            stroke="currentColor"
            strokeWidth="4"
          ></circle>
          <path
            className="opacity-75"
            fill="currentColor"
            d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z"
          ></path>
        </svg>
        <span className="text-xl">Cargando...</span>
      </div>
    );
  }

  return (
    <div className="p-6">
      <h1 className="text-2xl font-bold mb-4">Panel de Estadísticas</h1>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-4">
        <div className="bg-white shadow-md rounded-lg p-4 flex items-center justify-between hover:shadow-lg transition-shadow">
          <div>
            <h2 className="text-xl font-semibold">Cobros de Hoy</h2>
            <p className="text-gray-600 text-lg mt-2">
              {new Intl.NumberFormat("es-MX", { style: "currency", currency: "MXN" }).format(todayPayments)}
            </p>
          </div>
          <div className="text-4xl text-blue-500">📅</div>
        </div>
        <div className="bg-white shadow-md rounded-lg p-4 flex items-center justify-between hover:shadow-lg transition-shadow">
          <div>
            <h2 className="text-xl font-semibold">Cobros del Mes</h2>
            <p className="text-gray-600 text-lg mt-2">
              {new Intl.NumberFormat("es-MX", { style: "currency", currency: "MXN" }).format(selectedMonthPayments)}
            </p>
          </div>
          <div className="text-4xl text-green-500">💵</div>
        </div>
        <div className="bg-white shadow-md rounded-lg p-4 flex items-center justify-between hover:shadow-lg transition-shadow">
          <div>
            <h2 className="text-xl font-semibold">Comercios Activos</h2>
            <p className="text-gray-600 text-lg mt-2">{activeBusinesses}</p>
          </div>
          <div className="text-4xl text-green-500">✔️</div>
        </div>
        <div className="bg-white shadow-md rounded-lg p-4 flex items-center justify-between hover:shadow-lg transition-shadow">
          <div>
            <h2 className="text-xl font-semibold">Comercios Inactivos</h2>
            <p className="text-gray-600 text-lg mt-2">{inactiveBusinesses}</p>
          </div>
          <div className="text-4xl text-red-500">❌</div>
        </div>
      </div>

      {/* Pestañas de navegación */}
      <div className="mb-4 flex justify-center gap-4">
        <button
          onClick={() => setActiveView("diarios")}
          className={`px-4 py-2 rounded ${activeView === "diarios" ? "bg-blue-500 text-white" : "bg-gray-200 text-gray-700"}`}
        >
          Ingresos Diarios
        </button>
        <button
          onClick={() => setActiveView("historicos")}
          className={`px-4 py-2 rounded ${activeView === "historicos" ? "bg-blue-500 text-white" : "bg-gray-200 text-gray-700"}`}
        >
          Histórico de Ingresos
        </button>
        <button
          onClick={() => setActiveView("reportes")}
          className={`px-4 py-2 rounded ${activeView === "reportes" ? "bg-blue-500 text-white" : "bg-gray-200 text-gray-700"}`}
        >
          Historial de Reportes
        </button>
        <button
          onClick={() => setActiveView("negociosSinCobro")}
          className={`px-4 py-2 rounded ${activeView === "negociosSinCobro" ? "bg-blue-500 text-white" : "bg-gray-200 text-gray-700"}`}
        >
          Negocios sin Cobro
        </button>
      </div>

      {renderContent()}

      {/* Modal para foto */}
      {selectedPhotoUrl && (
        <div className="fixed inset-0 flex items-center justify-center z-50 bg-black bg-opacity-50">
          <div className="bg-white p-4 rounded shadow-lg max-w-xl w-full relative">
            <button onClick={closePhotoModal} className="absolute top-2 right-2 text-gray-600">
              Cerrar ✕
            </button>
            <img src={selectedPhotoUrl} alt="Reporte" className="w-full h-auto object-cover rounded" />
          </div>
        </div>
      )}
    </div>
  );
};

export default AdminHome;
